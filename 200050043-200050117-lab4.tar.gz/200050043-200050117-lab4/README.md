https://youtu.be/DihOP19LQdg : for overall idea of how to use Node JS with Express and React JS
https://www.simplilearn.com/tutorials/reactjs-tutorial/login-page-in-reactjs : for initial idea of using React
General stackoverflow pages when we faced various errors through the process of writing code