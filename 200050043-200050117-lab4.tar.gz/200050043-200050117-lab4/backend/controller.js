const bcrypt = require("bcrypt");
const pool = require("./db");
const queries = require("./queries");
var session;
//var loginuser=false;

const executeQuery = (query, id_query2) => {
    return new Promise((resolve, reject) => {
      pool.query(query, id_query2, (error, result) => {
        if (error) {
          reject(error);
        }
        resolve(result);
      });
    });
};

const checkidexists = async (req, res) => {
    const id = req.body.id;
    const password = req.body.password;
    result1 = await executeQuery(queries.idofstud, [id]);
    // console.log('result1: ', result1.rows);
    if(result1.rows.length == 0) {
        result2 = await executeQuery(queries.idofinstr, [id]);
        // console.log('result2: ', result2.rows);
        if(result2.rows.length > 0) {
            result3 = await executeQuery(queries.checkidexists, [id]);
            // console.log('result3: ', result3.rows);
            if(result3.rows.length > 0) {
                hashed_pwd = result3.rows[0].hashed_password;
                let ress = await bcrypt.compare(password, hashed_pwd);
                if(ress) {
                    const data = {isInstr: true, instrPwdInc: false, idInc: false, pwdInc: false, isMatching: false};
                    res.send(data);
                } 
                else {
                    const data = {isInstr: false, instrPwdInc: true, idInc: false, pwdInc: false, isMatching: false};
                    res.send(data);
                }               
            }
            else {
                const data = {isInstr: false, instrPwdInc: false, idInc: true, pwdInc: false, isMatching: false};
                res.send(data);                
            }
        }
        else {
            const data = {isInstr: false, instrPwdInc: false, idInc: true, pwdInc: false, isMatching: false};
            res.send(data);                
        }
    }
    else {
        result4 = await executeQuery(queries.checkidexists, [id]);
        // console.log('result4: ', result4.rows);
        if(result4.rows.length > 0) {
            hashed_pwd = result4.rows[0].hashed_password;
            let ress1 = await bcrypt.compare(password, hashed_pwd);
            if(ress1) {
                session = req.session;
                session.userid = String(id);
                const data = {isInstr: false, instrPwdInc: false, idInc: false, pwdInc: false, isMatching: true};
                res.send(data);
            } 
            else {
                const data = {isInstr: false, instrPwdInc: false, idInc: false, pwdInc: true, isMatching: false};
                res.send(data);
            }               
        }
        else {
            const data = {isInstr: false, instrPwdInc: false, idInc: true, pwdInc: false, isMatching: false};
            res.send(data);                
        }        
    }
};

const getstudentbyid = async (req, res) => {
    let result1,result2,result3;
    if(session == undefined){
        console.log(session);
        const data = {id:false, info: result1, past_courses: result2, current_courses: result3};
        res.send(data);
        return;
    }
    const id_query2 = session.userid;
    // const id_query2 = req.body.id;
    result1 = await executeQuery(queries.getstudentbyidquery1, [id_query2]);
    result2 = await executeQuery(queries.getstudentbyidquery2, [id_query2]);
    result3 = await executeQuery(queries.getstudentbyidquery3, [id_query2]);
    // console.log(result2);
    const data = {id:true, info: result1.rows[0], past_courses: result2.rows, current_courses: result3.rows};
    res.send(data);
};

const dropdropcoursebyid = (req, res) => {
    const id = req.body.id;
    const courseId = req.body.courseId;
    const secId = req.body.secId;
    const sem = req.body.semester;
    const yr = req.body.year;
    pool.query(queries.dropdropcoursebyid, [id, courseId, secId, sem, yr], (error, results) => {
        const done = false;
        // console.log(results);
        res.send(!done);
    });
};

const getinstructorbyid = async (req, res) => {
    let result1,result2,result3;
    if(session==undefined || session==null){
        const data = {id:false, info: result1, past_courses: result2, current_courses: result3};
        res.send(data);
        return;
    }
    const inst_id = req.body.id;
    result1 = await executeQuery(queries.getinstructbyid, [inst_id]);
    result2 = await executeQuery(queries.getteachesinstprevious, [inst_id]);
    result3 = await executeQuery(queries.getteachesinstnow, [inst_id]);
    // console.log(result2);
    const data = {id:true, info: result1.rows[0], past_courses: result2.rows, current_courses: result3.rows};
    res.send(data);
};

const getcoursebyid = async (req, res) => {
    let result1,result2,result3,venue;
    if(session==undefined || session==null){
        const data = {id:false, info: result1, venue: venue, pre_req: result2, course_instructor: result3};
        res.send(data);
        return;
    }
    const course_id = req.body.id;
    result1 = await executeQuery(queries.getcourseid, [course_id]);
    venue = await executeQuery(queries.getvenue, [course_id]);
    result2 = await executeQuery(queries.getprereqbyid, [course_id]);
    result3 = await executeQuery(queries.getinstrbycid, [course_id]);
    const data = {id:true, info: result1.rows[0], venue: venue.rows[0], pre_req: result2.rows, course_instructor: result3.rows};
    res.send(data);
};

const getdept = async (req, res) => {
    let result1;
    if(session==undefined || session==null){
        const data = {id:false, dept_names: result1};
        res.send(data);
        return;
    }
    result1 = await executeQuery(queries.getalldept, [ ]);
    const data = {id:true, dept_names: result1.rows};
    res.send(data);
};

const getallcoursebydept = async (req, res) => {
    let result1;
    if(session==undefined || session==null){
        const data = {id:false, course_names: result1};
        res.send(data);
        return;
    }
    const dept_name = req.body.dept_name;
    result1 = await executeQuery(queries.getallcoursedept, [dept_name]);
    const data = {id:true, course_names: result1.rows};
    // console.log(data);
    res.send(data);
};

const regsearch = async (req, res) => {
    if(session==undefined || session==null) {
        // console.log("hi");
        const data = {id: false, course: [], section: [], semester: [], year: []};
        res.send(data);
        return;
    }
    const id_title = req.body.id_title;
    let ress = [];
    if(!id_title || id_title == undefined) {
        // console.log("hi");
        let x = await executeQuery(queries.regwhenempty, [ ]);
        ress = x.rows;
    }
    else {
        // console.log("hi again");
        const str = '%' + id_title + '%';
        let y = await executeQuery(queries.regwhensearch, [str]);
        ress = y.rows;
    }
    let result1 = {};
    let result = {};
    result1['id'] = true;
    result1['semester'] = ress[0].semester;
    result1['year'] = ress[0].year;
    ress.forEach(({course_id, title, sec_id}) =>
        course_id in result ? result[course_id].push(sec_id) : result[course_id]=[sec_id]);
    // console.log(result);
    result1['section'] = result;
    const myMap = ress.map(({course_id, title}) => ({course_id, title}));
    // console.log(myMap);
    let arr = Array.from(new Set(myMap.map(JSON.stringify)), JSON.parse);
    // console.log(arr);
    result1['course'] = arr;
    // console.log(result1);
    res.send(result1);
};

const regforcourse = async (req, res) => {
    if(session==undefined || session==null) {
        // console.log("hi");
        const data = { id:false, already_took: true, prereq_unsat: false, slot_clash: false, insert_done: false};
        res.send(data);
        return;
    }
    const id = session.userid;
    const courseId = req.body.courseId;
    const secId = req.body.secId;
    const sem = req.body.semester;
    const yr = req.body.year;
    let result1 = await executeQuery(queries.ifalreadyregpass, [id, courseId]);
    if(result1.rows.length > 0) {
        // console.log("hi-already took course");
        const data = {id:true, already_took: true, prereq_unsat: false, slot_clash: false, insert_done: false};
        res.send(data);
        return;
    }
    let result2 = await executeQuery(queries.checkprereq, [id, courseId]);
    console.log(result2.rows);
    if(result2.rows.length > 0) {
        // console.log("hi-prereq not satisying");
        const data = {id:true, already_took: false, prereq_unsat: true, slot_clash: false, insert_done: false};
        res.send(data);
        return;        
    }
    let result3 = await executeQuery(queries.checkslotclash, [id, courseId]);
    if(result3.rows.length > 0) {
        // console.log("hi-slot clashing");
        const data = {id:true, already_took: false, prereq_unsat: false, slot_clash: true, insert_done: false};
        res.send(data);
        return;        
    }
    let result4 = await executeQuery(queries.regcourse, [id, courseId, secId, sem, yr]);
    // console.log("hi-insert done!");
    const data = {id:true, already_took: false, prereq_unsat: false, slot_clash: false, insert_done: true};
    res.send(data);
}

const logout = async(req,res) => {
    session=req.session.destroy();
    session=undefined;
    if(session==undefined || session == null){
        res.send({id:false});
    }
    else{
        res.send({id:true});
    }
}

module.exports = {
    checkidexists,
    getstudentbyid,
    dropdropcoursebyid,
    getinstructorbyid,
    getcoursebyid,
    getdept,
    getallcoursebydept,
    regforcourse,
    regsearch,
    logout,
};