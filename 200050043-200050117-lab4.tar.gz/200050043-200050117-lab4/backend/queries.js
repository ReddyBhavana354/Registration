// for login page
const idofstud = "SELECT * FROM student WHERE id::integer = $1";
const idofinstr = "SELECT * FROM instructor WHERE id::integer = $1";
const checkidexists = "SELECT * FROM user_password WHERE id::integer = $1";

// for home page of students
const getstudentbyidquery1 = "SELECT * FROM student WHERE id::integer = $1";
const getstudentbyidquery2 = "SELECT course_id, sec_id, takes.semester, takes.year, grade FROM takes, (SELECT year, semester FROM reg_dates WHERE start_time < now() ORDER BY start_time DESC LIMIT 1) AS x WHERE id::integer = $1 AND (takes.year < x.year OR (takes.year = x.year AND (CASE takes.semester WHEN 'Spring' THEN 1 WHEN 'Summer' THEN 2 WHEN 'Fall' THEN 3 WHEN  'Winter' THEN 4 END) < (CASE x.semester WHEN 'Spring' THEN 1 WHEN 'Summer' THEN 2 WHEN 'Fall' THEN 3 WHEN  'Winter' THEN 4 END))) ORDER BY (takes.year, (CASE takes.semester WHEN 'Spring' THEN 1 WHEN 'Summer' THEN 2 WHEN 'Fall' THEN 3 WHEN  'Winter' THEN 4 END)) DESC";
const getstudentbyidquery3 = "SELECT course_id, sec_id, takes.semester, takes.year, grade FROM takes, (SELECT year, semester FROM reg_dates WHERE start_time < now() ORDER BY start_time DESC LIMIT 1) AS x WHERE id::integer = $1 AND (takes.year = x.year AND takes.semester = x.semester) ORDER BY year DESC";

// for dropping courses in home page of students
const dropdropcoursebyid = "DELETE FROM takes WHERE id::integer = $1 AND course_id = $2 AND sec_id = $3 AND semester = $4 AND year = $5";

// for instructor page
const getinstructbyid = "SELECT name, dept_name FROM instructor WHERE id::integer = $1";
const getteachesinstprevious = "SELECT teaches.course_id, title, teaches.semester, teaches.year FROM teaches, course, (SELECT year, semester FROM reg_dates WHERE start_time < now() ORDER BY start_time DESC LIMIT 1) AS x WHERE id::integer = $1 AND (teaches.year < x.year OR (teaches.year = x.year AND (CASE teaches.semester WHEN 'Spring' THEN 1 WHEN 'Summer' THEN 2 WHEN 'Fall' THEN 3 WHEN  'Winter' THEN 4 END) < (CASE x.semester WHEN 'Spring' THEN 1 WHEN 'Summer' THEN 2 WHEN 'Fall' THEN 3 WHEN  'Winter' THEN 4 END))) AND course.course_id = teaches.course_id ORDER BY (teaches.year, (CASE teaches.semester WHEN 'Spring' THEN 1 WHEN 'Summer' THEN 2 WHEN 'Fall' THEN 3 WHEN  'Winter' THEN 4 END)) DESC";
const getteachesinstnow = "SELECT teaches.course_id, title, teaches.semester, teaches.year FROM teaches, course, (SELECT year, semester FROM reg_dates WHERE start_time < now() ORDER BY start_time DESC LIMIT 1) AS x WHERE id::integer = $1 AND (teaches.year = x.year AND teaches.semester = x.semester) AND course.course_id = teaches.course_id ORDER BY teaches.course_id";

//for registration page
const regwhenempty = "SELECT course.course_id, title, sec_id, x.semester, x.year FROM course, section, (SELECT year, semester FROM reg_dates WHERE start_time <= now() AND year > 2005 ORDER BY start_time DESC LIMIT 1) AS x WHERE course.course_id = section.course_id AND x.year = section.year AND x.semester = section.semester ORDER BY course.course_id";
const regwhensearch = "SELECT course.course_id, title, sec_id, x.semester, x.year FROM course, section, (SELECT year, semester FROM reg_dates WHERE start_time <= now() AND year > 2005 ORDER BY start_time DESC LIMIT 1) AS x WHERE course.course_id = section.course_id AND x.year = section.year AND x.semester = section.semester AND (course.course_id ILIKE $1 OR title ILIKE $1) ORDER BY course.course_id";
const ifalreadyregpass = "SELECT * FROM takes, (SELECT year, semester FROM reg_dates WHERE start_time <= now() AND year > 2005 ORDER BY start_time DESC LIMIT 1) AS x WHERE id::integer = $1 AND course_id = $2 AND (takes.year < x.year OR (takes.year = x.year AND (CASE takes.semester WHEN 'Spring' THEN 1 WHEN 'Summer' THEN 2 WHEN 'Fall' THEN 3 WHEN  'Winter' THEN 4 END) <= (CASE x.semester WHEN 'Spring' THEN 1 WHEN 'Summer' THEN 2 WHEN 'Fall' THEN 3 WHEN  'Winter' THEN 4 END))) AND grade != 'F'";
const checkprereq = "(SELECT prereq_id FROM prereq WHERE course_id = $2) EXCEPT (SELECT course_id FROM takes, (SELECT year, semester FROM reg_dates WHERE start_time <= now() AND year > 2005 ORDER BY start_time DESC LIMIT 1) AS x WHERE id::integer = $1 AND (takes.year < x.year OR (takes.year = x.year AND (CASE takes.semester WHEN 'Spring' THEN 1 WHEN 'Summer' THEN 2 WHEN 'Fall' THEN 3 WHEN  'Winter' THEN 4 END) < (CASE x.semester WHEN 'Spring' THEN 1 WHEN 'Summer' THEN 2 WHEN 'Fall' THEN 3 WHEN  'Winter' THEN 4 END))))";
const checkslotclash = "SELECT * FROM (SELECT section.time_slot_id FROM section, (SELECT year, semester FROM reg_dates WHERE start_time <= now() AND year > 2005 ORDER BY start_time DESC LIMIT 1) AS x WHERE section.course_id = $2 AND section.semester = x.semester AND section.year = x.year) AS y, (SELECT DISTINCT section.time_slot_id FROM section, takes, (SELECT year, semester FROM reg_dates WHERE start_time <= now() AND year > 2005 ORDER BY start_time DESC LIMIT 1) AS x WHERE id::integer = $1 AND section.course_id = takes.course_id AND section.sec_id = takes.sec_id AND section.semester = x.semester AND section.year = x.year) AS z WHERE y.time_slot_id = z.time_slot_id";
const regcourse = "INSERT INTO takes (ID, course_id, sec_id, semester, year, grade) VALUES ($1, $2, $3, $4, $5, '')";

// for course page
const getcourseid = "SELECT course_id, title, credits FROM course WHERE course_id = $1";
const getvenue = "SELECT building, room_number, time_slot_id FROM section, (SELECT year, semester FROM reg_dates WHERE start_time < now() ORDER BY start_time DESC LIMIT 1) AS x WHERE course_id = $1 AND section.semester = x.semester and section.year = x.year";
const getprereqbyid = "SELECT prereq_id, title FROM prereq, course WHERE prereq_id = course.course_id AND prereq.course_id = $1";
const getinstrbycid = "SELECT instructor.id, name, sec_id FROM teaches, instructor, (SELECT year, semester FROM reg_dates WHERE start_time < now() ORDER BY start_time DESC LIMIT 1) AS x WHERE instructor.id = teaches.id AND course_id = $1 AND teaches.year = x.year AND teaches.semester = x.semester"; 

// for all courses running in current semester
const getalldept = "SELECT DISTINCT dept_name FROM section, course, (SELECT year, semester FROM reg_dates WHERE start_time < now() ORDER BY start_time DESC LIMIT 1) AS x WHERE section.course_id = course.course_id AND section.semester = x.semester AND section.year = x.year";
const getallcoursedept = "SELECT DISTINCT section.course_id, title FROM section, course, (SELECT year, semester FROM reg_dates WHERE start_time < now() ORDER BY start_time DESC LIMIT 1) AS x WHERE section.course_id = course.course_id AND dept_name = $1 AND section.semester = x.semester AND section.year = x.year";

module.exports = {
    idofstud,
    idofinstr,
    checkidexists,

    getstudentbyidquery1,
    getstudentbyidquery2,
    getstudentbyidquery3,

    dropdropcoursebyid,

    regwhenempty,
    regwhensearch,
    ifalreadyregpass,
    checkprereq,
    checkslotclash,
    regcourse,

    getcourseid,
    getvenue,
    getprereqbyid,
    getinstructbyid,

    getinstrbycid,
    getteachesinstprevious,
    getteachesinstnow,
    
    getalldept,
    getallcoursedept,
};

