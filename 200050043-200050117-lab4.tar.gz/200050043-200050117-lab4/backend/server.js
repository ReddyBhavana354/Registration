cors = require("cors");

const express = require('express');
const studentroutes =require("./routes");
const bodyParser = require('body-parser');
const sessions = require('express-session');

const port = 8080;

const app = express();

app.use(cors({origin: 'http://localhost:3000', credentials:true }));
app.use(express.json());
app.use(express.urlencoded());
app.use(bodyParser.json());
app.use(sessions({
  secret: 'ViratKohliIsAwesome',
  resave: true,
  saveUninitialized: true
}));

app.use("/", studentroutes);

app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });
  