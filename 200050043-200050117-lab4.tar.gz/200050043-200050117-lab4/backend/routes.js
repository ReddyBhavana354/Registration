const { Router } = require('express');
const controller = require('./controller');
const router = Router();

router.post('/login', controller.checkidexists);
router.get('/home', controller.getstudentbyid);
router.post('/drop/:id/:courseId', controller.dropdropcoursebyid);
router.post('/instructor/:id', controller.getinstructorbyid);
router.post('/course/:id', controller.getcoursebyid);
router.get('/course/running/', controller.getdept);
router.post('/course/running/:dept_name', controller.getallcoursebydept);
router.get('/home/registration/no', controller.regsearch);
router.post('/home/registration/:search', controller.regsearch);
router.post('/register', controller.regforcourse);
router.post('/logout',controller.logout);

// added 

module.exports = router;