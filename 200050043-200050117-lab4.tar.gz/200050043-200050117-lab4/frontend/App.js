// import './App.css';
import React from 'react';
import Login from './Components/login';
import Home from './Components/home';
import Instructor from './Components/instructor';
import Course from './Components/course';
import Department from './Components/deptrunning';
import DepartmentCourses from './Components/deptcourses';
import Start from './Components/start';
import Registration from './Components/registration';
import Logout from './Components/logout';
import { BrowserRouter, Route, Routes } from "react-router-dom";

function App() {
	return (	  
		<div className='app'>
			<BrowserRouter>
				<Routes>
					<Route exact path ={"/"} element={<Start/>} />
					<Route exact path={"/login"} element={<Login/>} />
					<Route exact path={"/home"} element={<Home/>} />
					<Route exact path={"/instructor/:id"} element={<Instructor/>} />
					<Route exact path={"/course/:id"} element={<Course/>} />
					<Route exact path={"/course/running"} element={<Department/>} />
					<Route exact path={"/course/running/:dept_name"} element={<DepartmentCourses/>} />
					<Route exact path={"/home/registration"} element={<Registration/>} />
					<Route exact path={"/logout"} element={<Logout/>} />
				</Routes>
			</BrowserRouter>
		</div>
	)
  }

export default App;