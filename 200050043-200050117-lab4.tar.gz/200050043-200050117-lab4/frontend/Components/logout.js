import React, { useState, useEffect } from 'react';
import {useNavigate } from 'react-router-dom';
import './/Styling/Login.css';

const Logout = () => {
    const [isUser,setIsUser] = useState(false);
    const [error, setError] = useState(null);
    const navigate = useNavigate();
    useEffect(() => {
        (async () => {
            try {
                let res = await fetch('http://localhost:8080/logout/', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                });
                let result = await res.json();
                //setData(result);
                // console.log(result);
                if(result.id){
                    setIsUser(true);
                }
            } 
            catch (error) {
                setError(error);
            }
            // console.log(isTeaching);
        })();
    }, [ ]);
    if(!isUser){
        return(
            <div class="login-container">
                <p>
                    Kindly login first to access this!
                </p>
                <button onClick={() => navigate("/login")}>
                    Go to Login
                </button>

            </div>
        )
    }

    if (error) {
        return (
            <p>
                An error occurred ({error.message})
                Kindly reload the page!
            </p>
        );
    }

}

export default Logout;


