import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './/Styling/Login.css';
const Start = () => {
    const navigate = useNavigate();
    return(
        <div class='login-container'>
            <p>
                Kindly login first to access this!
            </p>
            <button onClick={() => navigate("/login")}>
                Go to Login
            </button>

        </div>
    )
}

export default Start
