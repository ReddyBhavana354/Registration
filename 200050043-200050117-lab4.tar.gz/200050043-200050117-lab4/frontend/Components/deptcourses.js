import React, { useState, useEffect } from 'react';
import { useParams,useNavigate } from 'react-router-dom';
import './/Styling/course.css';
import './/Styling/Login.css';

const DepartmentCourses = () => {
    let { dept_name } = useParams();
    // console.log(dept_name);
    const [data, setData] = useState(null);
    const [error, setError] = useState(null);
    const [isRunning, setIsRunning] = useState(true);
    const [isUser, setIsUser] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        (async () => {
            try {
                let res = await fetch('http://localhost:8080/course/running/'+dept_name, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ dept_name }),
                });
                let result = await res.json();
                // console.log(result);
                setData(result);
                if(result.id){
                    setIsUser(true);
                }
                // console.log(result.course_names);
                if(result.course_names.length == 0) {
                    setIsRunning(false);
                }
            } 
            catch (error) {
                setError(error);
            }
        })();
    }, [dept_name]);

    if(!isUser){
        return(
            <div class="login-container">
                <p>
                    Kindly login first to access this!
                </p>
                <button onClick={() => navigate("/login")}>
                    Go to Login
                </button>

            </div>
        )
    }

    if (error) {
        return (
            <p>
                An error occurred ({error.message})
                Kindly reload the page!
            </p>
        );
    }

    if (!data) {
        return <p>Loading...</p>;
    }

    return (
        <div  class="container">
            <a href={'/logout'}>Logout</a>
            <a href={'/home'}>Home</a>
        { isRunning               
        ?   (<div>
            <h2>The following courses are being offered this semester: </h2>
                <table style={{ borderCollapse: "collapse" }}>
                    <thead>
                        <tr>
                            <th style={{ border: "1px solid black" }}>Course ID</th>
                            <th style={{ border: "1px solid black" }}>Title</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.course_names.map(course => (
                            <tr key={course.course_id}>
                                <td style={{ border: "1px solid black" }}>
                                <a href={'/course/'+course.course_id}>{course.course_id}</a>
                                </td>
                                <td style={{ border: "1px solid black" }}>{course.title}</td>
                            </tr>
                        ))}
                    </tbody>
                </table> 
            </div>)
        :   (<h2> { dept_name } department is not offering any courses this sem! </h2>)
        }   
        </div>      
    );
};

export default DepartmentCourses