import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import './/Styling/course.css';
import './/Styling/Login.css';

const Instructor = () => {
    let { id } = useParams();
    const [data, setData] = useState(null);
    // const [error, setError] = useState(null);
    const [isTeaching, setIsTeaching] = useState(true);
    const [hasTaught, setHasTaught] = useState(true);
    const [isUser,setIsUser] = useState(false);
    const navigate=useNavigate();
    useEffect(() => {
        (async () => {
            let res = await fetch('http://localhost:8080/instructor/'+id, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id }),
            });
            let result = await res.json();
            setData(result);
            // console.log(result.current_courses.length);
            if(result.id){
                setIsUser(true);
            }
            if(result.current_courses.length == 0) {
                setIsTeaching(false);
            }
            if(result.past_courses.length == 0) {
                setHasTaught(false);
            }
            // console.log(isTeaching);
        })();
    }, [id]);
    if(!isUser){
        return(
            <div class="login-container">
                <p>
                    Kindly login first to access this!
                </p>
                <button onClick={() => navigate("/login")}>
                    Go to Login
                </button>

            </div>
        )
    }

    if (!data) {
        return <p>Loading...</p>;
    }

    return (
        <div class="container">
            <a href={'/logout'}>Logout</a>
            <a href={'/home'}>Home</a>
            <div class="box">
                <h2>Name: {data.info.name}</h2>
                <h2>Department: {data.info.dept_name}</h2>
            </div>
            { isTeaching               
            ?   (<div>
                    <h2>Current Semester: {data.current_courses[0].semester} {data.current_courses[0].year}</h2>
                    <table style={{ borderCollapse: "collapse" }}>
                        <thead>
                        <tr>
                            <th style={{ border: "1px solid black" }}>Course ID</th>
                            <th style={{ border: "1px solid black" }}>Title</th>
                        </tr>
                        </thead>
                        <tbody>
                            {data.current_courses.map(item => (
                                <tr key={item.id}>
                                    <td style={{ border: "1px solid black" }}>
                                        <a href={'/course/'+item.course_id}>{item.course_id}</a>
                                    </td>
                                    <td style={{ border: "1px solid black" }}>{item.title}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>)
            :   <div>
                    <h2>  Current Sem Courses</h2>
                        (<h3> {data.info.name} isn't offering any courses this sem </h3>)
                </div>
            }
        
            { hasTaught               
            ?   (<div>
                    <h2>Courses offered previously:</h2>
                    <table style={{ borderCollapse: "collapse" }}>
                        <thead>
                            <tr>
                                <th style={{ border: "1px solid black" }}>Course ID</th>
                                <th style={{ border: "1px solid black" }}>Title</th>
                                <th style={{ border: "1px solid black" }}>Semester</th>
                                <th style={{ border: "1px solid black" }}>Year</th>
                            </tr>
                        </thead>
                        <tbody>
                            {data.past_courses.map(course => (
                                <tr key={data.past_courses.course_id}>
                                    <td style={{ border: "1px solid black" }}>{course.course_id}</td>
                                    <td style={{ border: "1px solid black" }}>{course.title}</td>
                                    <td style={{ border: "1px solid black" }}>{course.semester}</td>
                                    <td style={{ border: "1px solid black" }}>{course.year}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>)
            :   (<h2> No courses were offered by {data.info.name} previously </h2>)
            }                    
        </div>
    );
};

export default Instructor