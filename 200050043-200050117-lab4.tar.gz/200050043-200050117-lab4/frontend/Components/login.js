import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './/Styling/Login.css';

const Login = () => { 
	const [id, setId] = useState(""); 
	const [password, setPassword] = useState(""); 
  // const [error, setError]= useState("");
  // const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();

	const HandleSubmit = async (e) => {
    e.preventDefault();
    let res = await fetch('http://localhost:8080/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, password }),
    });
    let result = await res.json();
    console.log(result);
    if(result.isInstr) {
      alert('This is the ID of an authorized instructor!');
    }
    if(result.instrPwdInc) {
      alert('This is the ID of an authorized instructor, but password you entered is incorrect!');
    }
    if(result.pwdInc) {
      alert('Incorrect Password!');
    }
    if(result.idInc) {
      alert('Incorrect ID!');
    }
    if(result.isMatching) {
      alert('Login successful! Click on OK to go to home page.');
      navigate("/home");
    }

    // await axios.post("http://localhost:3000/login").then((res) => {
    //   console.log("axios get done")
    //   console.log(res.data);
    //   localStorage.setItem("token", res.data.token);
    //   if (res.data.success) {
    //     console.log("hi again")
    //     sessionStorage.setItem('user', JSON.stringify({ id }));
    //     setIsLoggedIn(true);
    //   } 
    //   else {
    //     alert('Incorrect id or password');
    //   }
    // }).catch ((err) => {
    //   setError(err.response.data.error);
    // });

  };

	return(
    <div class="login-container">
      <h1> Log In</h1>
      <form action="" onSubmit={HandleSubmit}> 
        <div class="form-group"> 
          <label htmlFor="id">id</label>
          <input type="text" name="id" id="id" value={id} onChange={(e)=>setId(e.target.value)}/> 
        </div> 
        <div class="form-group"> 
          <label htmlFor="password">Password</label>
          <input type="password" name="password" id="password" value={password} onChange={(e)=>setPassword(e.target.value)}/> 
        </div>  
        <button type="submit" >Login</button>
      </form>
    </div>
  )
} 

export default Login