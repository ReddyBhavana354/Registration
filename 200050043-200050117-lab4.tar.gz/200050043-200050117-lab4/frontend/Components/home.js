import React, { useState, useEffect } from 'react';
// import { useParams } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import './/Styling/course.css';
import './/Styling/Login.css';

const Home = () => {
    // let { id } = useParams();
    const [data, setData] = useState(null);
    const [error, setError] = useState(null);
    const [isTaking, setIsTaking] = useState(true);
    const [isUser, setIsUser] = useState(false);
    const navigate = useNavigate();
    useEffect(() => {
        (async () => {
            try {
                // let res = await fetch('http://localhost:8080/home/'+, {
                //         method: 'GET',
                //         headers: { 'Content-Type': 'application/json' },
                //         body: JSON.stringify({ id }),
                // });
                let res = await fetch('http://localhost:8080/home', {
                    method: 'GET',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                });
                let result = await res.json();
                setData(result);
                // console.log(result);
                // setPrevData(data);
                // console.log(result.current_courses);
                // if(result.current_courses.length === 0) {
                //     setIsTaking(false);
                // }
                if(result.id){
                    setIsUser(true)
                    if(result.current_courses.length === 0) {
                        setIsTaking(false);
                    }
                }
                console.log(isUser);
            } 
            catch (error) {
                setError(error);
            }
        })();
    }, []);

    const handleDrop = async (id, courseId, secId, semester, year) => {
        try {
            // console.log(id);
            let res = await fetch('http://localhost:8080/drop/'+id+'/'+courseId, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id, courseId, secId, semester, year }),
            });
            let result = await res.json();
            const str = 'You have dropped ' + courseId + ' successfully';
            alert(str);
            window.location.reload(false);
            // setData((prevData) => ({
            //     ...prevData,
            //     current_courses: prevData.current_courses.filter(
            //         (course) => course.course_id !== courseId && course.sec_id !== secId
            //     ),
            // }));
            // const refresh = () => window.location.reload(true);
        } 
        catch (error) {
            setError(error);
        }
    };
    
    if(!isUser){
        return(
            <div class="login-container">
                <p>
                    Kindly login first to access this!
                </p>
                <button onClick={() => navigate("/login")}>
                    Go to Login
                </button>

            </div>
        )
    }

    if (error) {
        return (
            <p>
                An error occurred ({error.message})
                Kindly reload the page or check whether u loged in !
            </p>
        );
    }

    if (!data) {
        return <p>Loading...</p>;
    }

    return (
        <div class="container">
            <a href={'/logout'}>Logout</a>
            <div class="box">
                <h2>ID: {data.info.id}</h2>
                <h2>Name: {data.info.name}</h2>
                <h2>Department: {data.info.dept_name}</h2>
                <h2>Total Credits: {data.info.tot_cred}</h2>
            </div>
            <h2>
            <a href={'/course/running'}>Check out all departments which are offering courses this sem</a>
            </h2>
            { isTaking               
            ?   (<div>
                    <h2>Current Semester: {data.current_courses[0].semester} {data.current_courses[0].year}</h2>
                    <h3>
                        <a href={'/home/registration'}>Register for more courses</a>
                    </h3>
                    <table style={{ borderCollapse: "collapse" }}>
                        <thead>
                        <tr>
                            <th style={{ border: "1px solid black" }}>Course ID</th>
                            <th style={{ border: "1px solid black" }}>Section</th>
                            {/* <th style={{ border: "1px solid black" }}>Grade</th> */}
                            <th style={{ border: "1px solid black" }}>Drop Course</th>
                        </tr>
                        </thead>
                        <tbody>
                            {data.current_courses.map(item => (
                                <tr key={item.course_id}>
                                    <td style={{ border: "1px solid black" }}>{item.course_id}</td>
                                    <td style={{ border: "1px solid black" }}>{item.sec_id}</td>
                                    {/* <td style={{ border: "1px solid black" }}>{item.grade}</td> */}
                                    <td style={{ border: "1px solid black" }}>
                                        <button class="drop-btn" onClick={() => handleDrop(data.info.id, item.course_id, item.sec_id, item.semester, item.year)}>Drop</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>)
            :   (<div>
                    <h2> You haven't registered for any courses in the current semester yet </h2>
                    <h3>
                        <a href={'/home/registration'}>Register for courses</a>
                    </h3>
                </div>)
            }

            {
            [...new Set(data.past_courses.map(course_id => course_id.year))].sort((a, b) => b - a).map(year => {
                const semesters = [...new Set(data.past_courses.filter(course_id => course_id.year === year).map(course_id => course_id.semester))];
                const semesterMap = {
                    'Spring': 1,
                    'Summer': 2,
                    'Fall': 3,
                    'Winter': 4,
                };
                const sortedSemesters = semesters.sort((a, b) => semesterMap[b] - semesterMap[a]);
                return (
                    <div key={year} style={{ textAlign: "center" }}>
                        <h2>{year}</h2>
                        {sortedSemesters.map(semester => (
                            <table key={semester} style={{ borderCollapse: "collapse", margin: "0 auto", marginBottom: "1em", width: "80%" }}>
                            <thead>
                                <tr>
                                <th style={{ border: "1px solid black" }}>Semester</th>
                                <th style={{ border: "1px solid black" }}>Course ID</th>
                                <th style={{ border: "1px solid black" }}>Section</th>
                                <th style={{ border: "1px solid black" }}>Grade</th>
                                </tr>
                            </thead>
                            <tbody>
                                {data.past_courses.filter(course_id => course_id.year === year && course_id.semester === semester).map(course => (
                                <tr key={data.past_courses.course_id}>
                                    <td style={{ border: "1px solid black" }}>{course.semester}</td>
                                    <td style={{ border: "1px solid black" }}>{course.course_id}</td>
                                    <td style={{ border: "1px solid black" }}>{course.sec_id}</td>
                                    <td style={{ border: "1px solid black" }}>{course.grade}</td>
                                </tr>
                                ))}
                            </tbody>
                            </table>
                        ))}
                    </div>
                );
            })}
        </div>
    );
};

export default Home