import React, { useState, useEffect } from 'react';
import { useParams,useNavigate } from 'react-router-dom';
import './/Styling/course.css';
import './/Styling/Login.css';

const Course = () => {
    let { id } = useParams();
    const [data, setData] = useState(null);
    const [error, setError] = useState(null);
    const [isOffered, setIsOffered] = useState(true);
    const [havePrereq, setHavePrereq] = useState(true);
    const [isUser,setIsUser] = useState(false);
    const navigate = useNavigate();
    useEffect(() => {
        (async () => {
            try {
                let res = await fetch('http://localhost:8080/course/'+id, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id }),
                });
                let result = await res.json();
                setData(result);
                // console.log(result);
                if(result.id){
                    setIsUser(true);
                }

                if(result.course_instructor.length == 0) {
                    // console.log("Hi");
                    setIsOffered(false);
                }

                if(result.pre_req.length == 0) {
                    // console.log("Hi");
                    setHavePrereq(false);
                }
            } 
            catch (error) {
                setError(error);
            }
            // console.log(isTeaching);
        })();
    }, [id]);
    if(!isUser){
        return(
            <div class='login-container'>
                <p>
                    Kindly login first to access this!
                </p>
                <button onClick={() => navigate("/login")}>
                    Go to Login
                </button>

            </div>
        )
    }

    if (error) {
        return (
            <p>
                An error occurred ({error.message})
                Kindly reload the page!
            </p>
        );
    }

    if (!data) {
        return <p>Loading...</p>;
    }

    return (
        <div class="container">
            <p><a href={'/logout'}>Logout</a></p>
            <p><a href={'/home'}>Home</a></p>
        { isOffered
        ?   (<div>
                <div class='box'>
                    <h1>Course ID: {data.info.course_id}</h1>
                    <h1>Course Name: {data.info.title}</h1>
                    <h2>Credits: {data.info.credits}</h2>
                </div>

                { havePrereq               
                ?   (<div>
                        <h2>Prereq </h2>
                        <table>
                            <thead>
                            <tr>
                                <th>Prereq ID</th>
                                <th>Title</th>
                            </tr>
                            </thead>
                            <tbody>
                                {data.pre_req.map(item => (
                                    <tr key={item.prereq_id}>
                                        <td>
                                            <a href={'/course/'+item.prereq_id}>{item.prereq_id}</a>
                                        </td>
                                        <td>{item.title}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>)
                :   (
                    <div>
                        <h1> Prerequisites:</h1>
                        <h3> There is no prereq for {data.info.course_id} </h3>
                    </div>)
                }
            
                <h2>Course Instructor(s): </h2>
                <table style={{ borderCollapse: "collapse" }}>
                    <thead>
                        <tr>
                            <th>Instructor ID</th>
                            <th>Instructor Name</th>
                            <th>Section</th>
                        </tr>                    
                    </thead>
                    <tbody>
                        {data.course_instructor.map(instr => (
                            <tr key={instr.id}>
                                <td>
                                <a href={'/instructor/'+instr.id}>{instr.id}</a>
                                </td>
                                <td>{instr.name}</td>
                                <td>{instr.sec_id}</td>
                            </tr>
                        ))}
                    </tbody>
                        </table>
            </div>)
        :   //<h2>This course {data.info.course_id}: { data.info.title } is not being offered this sem!</h2>
            (
            <div>
                <div class='box'>
                    <h1>Course ID: {data.info.course_id}</h1>
                    <h1>Course Name: {data.info.title}</h1>
                    <h2>Credits: {data.info.credits}</h2>
                </div>
                { havePrereq               
                ?   (<div>
                        <h2>Prereq </h2>
                        <table>
                            <thead>
                            <tr>
                                <th>Prereq ID</th>
                                <th>Title</th>
                            </tr>
                            </thead>
                            <tbody>
                                {data.pre_req.map(item => (
                                    <tr key={item.prereq_id}>
                                        <td>
                                            <a href={'/course/'+item.prereq_id}>{item.prereq_id}</a>
                                        </td>
                                        <td>{item.title}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>)
                :   (
                    <div>
                        <h1> Prerequisites:</h1>
                        <h3> There is no prereq for {data.info.course_id} </h3>
                    </div>)
                }
            </div>    
                )}
    </div>
    );
};

export default Course