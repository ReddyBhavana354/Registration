import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './/Styling/course.css';
import './/Styling/Login.css';
const Department = () => {
    const [data, setData] = useState(null);
    const [error, setError] = useState(null);
    const [isRunning, setIsRunning] = useState(true);
    const [isUser, setIsUser] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        (async () => {
            try {
                let res = await fetch('http://localhost:8080/course/running', {
                        method: 'GET',
                        headers: { 'Content-Type': 'application/json' },
                });
                let result = await res.json();
                // console.log(result);
                setData(result);
                // console.log(result.dept_names.length);
                if(result.id){
                    setIsUser(true);
                }
                if(result.dept_names.length == 0) {
                    setIsRunning(false);
                }
            } 
            catch (error) {
                setError(error);
            }
        })();
    });

    if(!isUser){
        return(
            <div class="login-container">
                <p>
                    Kindly login first to access this!
                </p>
                <button onClick={() => navigate("/login")}>
                    Go to Login
                </button>

            </div>
        )
    }

    if (error) {
        return (
            <p>
                An error occurred ({error.message})
                Kindly reload the page!
            </p>
        );
    }

    if (!data) {
        return <p>Loading...</p>;
    }

    return (
        <div class="container">
            <a href={'/logout'}>Logout</a>
            <a href={'/home'}>Home</a>
        { isRunning               
        ?   (<div>
            <h2>The following departments are offering courses this semester: </h2>
                <table style={{ borderCollapse: "collapse" }}>
                    <thead>
                        <tr>
                            <th style={{ border: "1px solid black" }}>Department Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.dept_names.map(department => (
                            <tr key={department.dept_name}>
                                <td style={{ border: "1px solid black" }}>
                                <a href={'/course/running/'+department.dept_name}>{department.dept_name}</a>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table> 
            </div>)
        :   (<h2> No department is offering any courses this sem! </h2>)
        }   
        </div>      
    );
};

export default Department