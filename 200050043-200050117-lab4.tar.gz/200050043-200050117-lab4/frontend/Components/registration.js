import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './/Styling/Login.css';

const Registration = () => {
    const [error, setError] = useState(null);
    const [selectedSections, setSelectedSections] = useState({});   
    const [course, setCourse] = useState(null);
    const [section, setSection] = useState(null);
    const [sem, setSem] = useState(null);
    const [yr, setYear] = useState(null);
    const [isRunning, setIsRunning] = useState(true);
    const [isUser, setIsUser] = useState(false);
    const [id_title, setIdTitle] = useState("");
    const navigate = useNavigate();

    useEffect(() => {
        (async () => {
            try {
                let res = await fetch('http://localhost:8080/home/registration/no', {
                        method: 'GET',
                        headers: { 'Content-Type': 'application/json' },
                });
                let result = await res.json();
                setCourse(result.course);
                setSection(result.section);
                setSem(result.semester);
                setYear(result.year);
                if(result.id) {
                    setIsUser(true);
                }
                if(result.course.length == 0) {
                    setIsRunning(false);
                }
            } 
            catch (error) {
                setError(error);
            }
        })();
    }, []);

    const handleSearch = async (e) => {
        e.preventDefault();
        // let { id_title } = useParams();
        // console.log(id_title)
        try {
            let res = await fetch('http://localhost:8080/home/registration/'+id_title, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id_title }),
            });
            let result = await res.json();
            setCourse(result.course);
            setSection(result.section);
            setSem(result.semester);
            setYear(result.year);
            // console.log(courses);
            if(result.id) {
                setIsUser(true);
            }
            if(result.course.length == 0) {
                setIsRunning(false);
            }
        } 
        catch (error) {
            setError(error);
        }
        return;
    };

    const handleChange = (courseId) => (e) => {
        setSelectedSections((prevSelectedSections) => ({
          ...prevSelectedSections,
          [courseId]: e.target.value,
        }));
    }; 

    const handleRegister = async (courseId, secId, semester, year) => {
        console.log(secId);
        if(secId == undefined || !secId) {
            console.log("hi");
            alert('Choose a section first!');
        }
        else{
            try {
                let res = await fetch('http://localhost:8080/register', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ courseId, secId, semester, year }),
                });
                let result = await res.json();
                if(result.already_took) {
                    // console.log("alreadyhi");
                    const str = 'You have already taken ' + courseId;
                    alert(str);
                }  
                else if(result.prereq_unsat) {
                    // console.log("prereqhi");
                    const str = 'You have not finished all the prereq courses for ' + courseId;
                    alert(str);
                }
                else if(result.slot_clash) {
                    // console.log("slothi");
                    alert('There is a slot clash with a registered course.');
                }
                else if(result.insert_done) {
                    // console.log("hi");
                    const str = 'You have now registered for ' + courseId;
                    alert(str);
                    setIdTitle("");
                    window.location.reload(false);
                }
            } 
            catch (error) {
                setError(error);
            }
        }
    };
    
    if(!isUser){
        return(
            <div class="login-container">
                <p>
                    Kindly login first to access this!
                </p>
                <button onClick={() => navigate("/login")}>
                    Go to Login
                </button>

            </div>
        )
    };

    if (error) {
        return (
            <p>
                An error occurred ({error.message})
                Kindly reload the page!
            </p>
        );
    };

    if (!course) {
        return <p>Loading...</p>;
    };

    return (
        <div>
            <a href={'/home'}>Home</a>
            <input
                type="text"
                placeholder="Type Course ID or Title"
                value={id_title}
                onChange={(e) => setIdTitle(e.target.value)}
            />
            <button onClick={handleSearch}>Search</button>
            { isRunning
            ?   (<div>
                <h2>Courses being offered in {sem} {yr}: </h2>
                    <table style={{ borderCollapse: "collapse" }}>
                        <thead>
                            <tr>
                                <th style={{ border: "1px solid black" }}>Course ID</th>
                                <th style={{ border: "1px solid black" }}>Course Name</th>
                                <th style={{ border: "1px solid black" }}>Section</th>
                                <th style={{ border: "1px solid black" }}>Register</th>
                            </tr>
                        </thead>
                        <tbody>
                            {course.map(course => (
                                <tr key={course.id}>
                                    <td style={{ border: "1px solid black" }}>{course.course_id}</td>
                                    <td style={{ border: "1px solid black" }}>{course.title}</td>
                                    <td style={{ border: "1px solid black" }}>
                                        <select value={selectedSections[course.course_id] || 'Choose Section'} onChange={handleChange(course.course_id)}>
                                            <option value="">Choose Section</option>
                                            {section[course.course_id].map((newitem, index) => (
                                                <option key={index} value={newitem}>{"S" + newitem}</option>
                                            ))}
                                        </select>
                                    </td>
                                    <td>
                                        <button class="register-btn" onClick={() => handleRegister(course.course_id, selectedSections[course.course_id], sem, yr)}>Register</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>)
            :   <h2>No courses are being offered this sem!</h2>}
        </div>      
    );
};

export default Registration